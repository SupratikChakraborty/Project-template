# Text Analyzer Tool Using JavaScript
I created a text analyzer tool using HTML, Bootstrap &amp; JavaScript
# Description
I have created text analyzer tool. This tool allows you to enter your text in text field and give you information about your text like:
1. Total Characters
2. Total Words
3. Total Spaces
4. Total UpperCase Characters
5. Total LowerCase Characters
6. Total Punctuation Marks
7. Total Numbers
# Demo
https://serene-golick-931220.netlify.app/
